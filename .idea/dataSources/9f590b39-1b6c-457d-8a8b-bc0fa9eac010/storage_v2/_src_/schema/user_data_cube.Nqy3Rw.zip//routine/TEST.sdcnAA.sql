create
  definer = root@`%` procedure TEST()
BEGIN
	DECLARE COUNT INT DEFAULT 20001;
	WHILE COUNT <= 27000 DO
	UPDATE usr_resident_cell SET ENODEB_ID = (SELECT t1.ENODEB_ID FROM tb_temp as t1 JOIN (SELECT round(rand() * ((SELECT MAX(ENODEB_ID) FROM tb_temp) - (SELECT min(ENODEB_ID) from tb_temp)) + (SELECT min(ENODEB_ID) from tb_temp)) as ENODEB_ID ) as t2 WHERE t1.ENODEB_ID >= t2.ENODEB_ID ORDER BY t1.ENODEB_ID LIMIT 1) WHERE ID = COUNT;
	SET COUNT = COUNT + 1; 
  END WHILE;
END;

